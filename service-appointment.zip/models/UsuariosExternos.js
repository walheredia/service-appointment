"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const database_1 = require("../config/database");
class UsuariosExternos {
    static findAllUsers() {
        return __awaiter(this, void 0, void 0, function* () {
            const generalConnection = (0, database_1.getGeneralDatabaseConnection)();
            const result = yield generalConnection.query('SELECT * FROM UsuariosExternos');
            return result.map((row) => ({
                Id: row.Id,
                Username: row.Username,
                EMail: row.EMail,
                PasswordHash: row.PasswordHash,
                CreatedAt: new Date(row.CreatedAt),
                UpdatedAt: new Date(row.UpdatedAt),
                DeletedAt: row.DeletedAt ? new Date(row.DeletedAt) : undefined,
            }));
        });
    }
    static findUserByUserName(username) {
        return __awaiter(this, void 0, void 0, function* () {
            const generalConnection = (0, database_1.getGeneralDatabaseConnection)();
            const result = yield generalConnection.query(`SELECT * FROM UsuariosExternos WHERE Username = '${username}' and DeletedAt is null`);
            if (result.length === 0)
                return null;
            const row = result[0];
            return {
                Id: row.Id,
                Username: row.Username,
                EMail: row.EMail,
                PasswordHash: row.PasswordHash,
                CreatedAt: new Date(row.CreatedAt),
                UpdatedAt: new Date(row.UpdatedAt),
                DeletedAt: row.DeletedAt ? new Date(row.DeletedAt) : undefined,
            };
        });
    }
    static create(user) {
        return __awaiter(this, void 0, void 0, function* () {
            const generalConnection = (0, database_1.getGeneralDatabaseConnection)();
            const sql = `
      INSERT INTO UsuariosExternos (Username, EMail, PasswordHash, CreatedAt, UpdatedAt)
      VALUES ('${user.Username}', '${user.EMail}', '${user.PasswordHash}', GETDATE(), GETDATE())
    `;
            yield generalConnection.query(sql);
        });
    }
    static update(id, user) {
        return __awaiter(this, void 0, void 0, function* () {
            const generalConnection = (0, database_1.getGeneralDatabaseConnection)();
            const updates = Object.entries(user).map(([key, value]) => `${key} = '${value}'`).join(', ');
            const sql = `UPDATE UsuariosExternos SET ${updates}, UpdatedAt = GETDATE() WHERE Id = ${id}`;
            yield generalConnection.query(sql);
        });
    }
    static delete(id) {
        return __awaiter(this, void 0, void 0, function* () {
            const generalConnection = (0, database_1.getGeneralDatabaseConnection)();
            const sql = `UPDATE UsuariosExternos SET DeletedAt = GETDATE() WHERE Id = ${id}`;
            yield generalConnection.query(sql);
        });
    }
}
exports.default = UsuariosExternos;
