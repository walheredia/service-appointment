"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getServicesConnection = exports.connectToServicesDatabase = exports.getGeneralDatabaseConnection = exports.connectToGeneralDatabase = void 0;
const dotenv_1 = __importDefault(require("dotenv"));
const odbc_1 = __importDefault(require("odbc"));
dotenv_1.default.config();
const dsnGeneralName = process.env.dsnGeneralName || 'dsnGeneral';
const uidGeneral = process.env.dsnGeneralUser || 'juan';
const pwdGeneral = process.env.dsnGeneralPass || '5871';
const dsnServicesName = process.env.dsnServicesName || 'dsnServicios';
const uidServices = process.env.dsnServicesUser || 'juan';
const pwdServices = process.env.dsnServicesPass || '5871';
let generalConnection;
let servicesConnection;
function connectToGeneralDatabase() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            //Connect to General DB
            generalConnection = yield odbc_1.default.connect(`DSN=${dsnGeneralName};UID=${uidGeneral};PWD=${pwdGeneral}`);
            console.log('Conexión exitosa al DSN:', dsnGeneralName);
            return generalConnection;
        }
        catch (error) {
            console.error('Error al conectar al DSN General:', error);
            throw error;
        }
    });
}
exports.connectToGeneralDatabase = connectToGeneralDatabase;
function getGeneralDatabaseConnection() {
    if (!generalConnection) {
        throw new Error('The database connection (General) has not been initialized.');
    }
    return generalConnection;
}
exports.getGeneralDatabaseConnection = getGeneralDatabaseConnection;
function connectToServicesDatabase() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            //Connect to Services DB
            servicesConnection = yield odbc_1.default.connect(`DSN=${dsnServicesName};UID=${uidServices};PWD=${pwdServices}`);
            console.log('Conexión exitosa al DSN:', dsnServicesName);
            return servicesConnection;
        }
        catch (error) {
            console.error('Error al conectar al DSN Services:', error);
            throw error;
        }
    });
}
exports.connectToServicesDatabase = connectToServicesDatabase;
function getServicesConnection() {
    if (!servicesConnection) {
        throw new Error('The database connection (Services) has not been initialized.');
    }
    return servicesConnection;
}
exports.getServicesConnection = getServicesConnection;
