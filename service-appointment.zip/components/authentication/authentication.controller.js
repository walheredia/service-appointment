"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.verifyToken = exports.generateToken = void 0;
const bcrypt_1 = __importDefault(require("bcrypt"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const config_1 = require("../../config");
const UsuariosExternos_1 = __importDefault(require("../../models/UsuariosExternos"));
const hash = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { password } = req.body;
        if (!password)
            return res.status(400).json({
                message: 'Password has not been provided'
            });
        const hash = yield createHash(password);
        return res.status(200).json({ "data": hash });
    }
    catch (error) {
        return res.status(500).json({
            message: 'An error has occurred.',
            detail: error
        });
    }
});
const createHash = (password) => __awaiter(void 0, void 0, void 0, function* () {
    const salt = yield bcrypt_1.default.genSalt(10);
    const hash = yield bcrypt_1.default.hash(password, salt);
    return hash;
});
const login = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { username, password } = req.body;
    if (!username || !password) {
        return res.status(400).json({ "error": "Please provide username and password parameters" });
    }
    const usuario = yield UsuariosExternos_1.default.findUserByUserName(username);
    if (!usuario) {
        return res.status(401).json({ "error": "Credentials are not valid" });
    }
    const hash = usuario === null || usuario === void 0 ? void 0 : usuario.PasswordHash; //get hash from db
    const passwordIsValid = yield validatePassword(password, hash || '');
    if (passwordIsValid) {
        const token = (0, exports.generateToken)({ username: username });
        const expiresInMs = 24 * 60 * 60 * 1000; // 24 horas en milisegundos
        const expiresIn = new Date(Date.now() + expiresInMs);
        return res.status(200).json({ token, expiresIn });
    }
    else {
        return res.status(401).json({ "error": "Credentials are not valid" });
    }
});
const validatePassword = (password, hash) => __awaiter(void 0, void 0, void 0, function* () {
    const isMatch = yield bcrypt_1.default.compare(password, hash);
    return isMatch;
});
const generateToken = (payload) => {
    return jsonwebtoken_1.default.sign(payload, config_1.jwtConfig.secret, { expiresIn: config_1.jwtConfig.expiresIn });
};
exports.generateToken = generateToken;
const verifyToken = (token) => {
    try {
        return jsonwebtoken_1.default.verify(token, config_1.jwtConfig.secret);
    }
    catch (error) {
        throw new Error('Invalid token');
    }
};
exports.verifyToken = verifyToken;
exports.default = {
    hash,
    login
};
